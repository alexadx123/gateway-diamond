// Aqui entraria a integração real com a Pix Up (usando axios por exemplo)
module.exports = {
  gerarCobrancaPix: async (dados) => {
    return { qr_code: 'codigo-ficticio' };
  }
};