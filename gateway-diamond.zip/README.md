# Gateway Diamond (Plano 3)

Versão expressa com API própria, Pix Up, KYC manual e painel simples.

## Rodar localmente
```bash
npm install
node server.js
```

## Rotas
- POST /api/payments
- POST /api/kyc