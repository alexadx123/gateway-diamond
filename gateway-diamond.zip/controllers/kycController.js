exports.submitKYC = (req, res) => {
  // Lógica mock de envio de KYC manual
  res.json({ message: "Documento recebido (mock)" });
};