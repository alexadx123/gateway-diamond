exports.createCharge = (req, res) => {
  // Lógica de criação de cobrança Pix Up
  res.json({ message: "Cobrança criada (mock)" });
};